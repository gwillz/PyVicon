// ViconDataStreamServer.cpp : main project file.

#include "stdafx.h"

#include "Client.h"

#using <System.dll>

using namespace System;
using namespace System::IO;
using namespace System::Net;
using namespace System::Net::Sockets;
using namespace System::Text;
using namespace System::Threading;

using namespace std;
using namespace ViconDataStreamSDK::CPP;
using namespace System::Runtime::InteropServices;

void connectToDataStream();
System::String^ executeRequest (System::String ^);
System::String^ getSubjects();
System::String^ getTranslation(string);
System::String^ getRotation(string);
System::String^ getAll();

Client myClient;

void main() {

	Console::WriteLine("Vicon DataStream Server");
	Console::WriteLine("Version 1.0"); Console::WriteLine();

   try {

      // Set the TcpListener.
	  System::String^ strIPAddress = "0.0.0.0";
	  IPAddress^ localAddr = IPAddress::Parse( strIPAddress );

	  Int32 port = 802;
	  
	  Console::WriteLine("Configuring server...");
	  Console::WriteLine("IP Address: " + strIPAddress);
	  Console::WriteLine("Port: " + port); Console::WriteLine();

      // TcpListener* server = new TcpListener(port);
      TcpListener^ server = gcnew TcpListener(localAddr,port);
	  
	  // Connect to Vicon DataStream.
	  connectToDataStream();

      // Start listening for client requests.
      server -> Start();
	  
	  Console::WriteLine("Server is online.");

      // Buffer for reading data
      array<Byte>^ bytes = gcnew array<Byte>(1024);
      System::String^ data = nullptr;

      // Enter the listening loop.
      while (true) {

         // Perform a blocking call to accept requests.
         // You could also user server.AcceptSocket() here.
         TcpClient^ client = server -> AcceptTcpClient();
         data = nullptr;

         // Get a stream Object* for reading and writing
         NetworkStream^ stream = client -> GetStream();
         Int32 i;

         // Loop to receive all the data sent by the client.
         while (i = stream->Read(bytes, 0, bytes -> Length)) {

            // Translate data bytes to a ASCII String*.
            data = Text::Encoding::ASCII -> GetString(bytes, 0, i);

			// Execute client request.
			data = executeRequest(data);

            array<Byte>^ msg = Text::Encoding::ASCII -> GetBytes(data);

            // Send back a response.
            stream -> Write(msg, 0, msg->Length);

		 }

         // Shutdown and end connection
         client -> Close();
	  }
   }

   catch (SocketException^ e) {
      Console::WriteLine("SocketException: {0}", e);
   }

   // Disconnect from Vicon DataStream.
   myClient.Disconnect();

   Console::ReadLine();

}

void connectToDataStream() {
	
	Console::WriteLine("Connecting to Vicon DataStream...");

	while(!myClient.IsConnected().Connected) {

		
		myClient.Connect("192.168.10.1:801");
		// Settings for Vicon DataStream.
		myClient.EnableSegmentData();
		myClient.SetStreamMode(ViconDataStreamSDK::CPP::StreamMode::ClientPull);

	}
	
	Console::WriteLine("Connected."); Console::WriteLine();
}

System::String ^ executeRequest (System::String ^ recievedData) {

	char * charRecievedData = (char*)(void*)Marshal::StringToHGlobalAnsi(recievedData);
	
	char * charRequest = strtok (charRecievedData, " ");
	std::string request = std::string(charRequest);
	
	if (myClient.GetFrame().Result != Result::Success) {
		return "0";
	}	

	if (request == "getSubjects") {
		return getSubjects();

	} else if (request == "getTranslation") {
		char * charParameter = strtok (NULL, " ");
		std::string parameter = std::string(charParameter);
		return getTranslation(parameter);

	} else if (request == "getRotation") {
		char * charParameter = strtok (NULL, " ");
		std::string parameter = std::string(charParameter);
		return getRotation(parameter);

	} else if (request == "getAll") {
		return getAll();

	} else {
		return "0";
	}

}

System::String ^ getSubjects() {

	// Returns the number of subjects and their names.
	// Format: [Number of subjects]<space>[Subject 1 name]<space>[Subject 2 name]<space>... etc.

	// Gets the subject count.
	unsigned int subjectCount = myClient.GetSubjectCount().SubjectCount;
	System::String ^ strSubjects = subjectCount.ToString();

	// Gets subject names.
	for(unsigned int subjectIndex = 0; subjectIndex < subjectCount; ++subjectIndex) {
		std::string stdStringSubjectName = myClient.GetSubjectName(subjectIndex).SubjectName;
		System::String ^ subjectName = gcnew System::String(stdStringSubjectName.c_str());
		strSubjects = strSubjects + " " + subjectName;
	}

	return strSubjects;
}

System::String ^ getTranslation(string subjectName) {

	// Returns global translation, i.e. X, Y, and Z coordinates of subjects.
	// Format: [X Coordinate]<space>[Y Coordinate]<space[Z Coordinate]
	

	// Gets translation.
	Output_GetSegmentGlobalTranslation _Output_GetSegmentGlobalTranslation = myClient.GetSegmentGlobalTranslation(subjectName, subjectName);

	System::String ^ strX = _Output_GetSegmentGlobalTranslation.Translation[0].ToString();
	System::String ^ strY = _Output_GetSegmentGlobalTranslation.Translation[1].ToString();
	System::String ^ strZ = _Output_GetSegmentGlobalTranslation.Translation[2].ToString();

	return strX + " " + strY + " " + strZ;

}

System::String ^ getRotation(string subjectName) {

	// Returns global helical rotation of subjects.
	// Format: [X Rotation]<space>[Y Rotation]<space[Z Rotation]
	
	// Gets global helical rotation.
	Output_GetSegmentGlobalRotationHelical _Output_GetSegmentGlobalRotationHelical = myClient.GetSegmentGlobalRotationHelical(subjectName, subjectName);
	
	System::String ^ strRX = _Output_GetSegmentGlobalRotationHelical.Rotation[0].ToString();
	System::String ^ strRY = _Output_GetSegmentGlobalRotationHelical.Rotation[1].ToString();
	System::String ^ strRZ = _Output_GetSegmentGlobalRotationHelical.Rotation[2].ToString();

	return strRX + " " + strRY + " " + strRZ;

}

System::String ^ getAll() {

	// Returns translations and rotatations of all subjects.
	// Format: [Number of subjects]<space>[Subject 1 name]<space>[Subject 1 translation]<space>[Subject 1 rotation]<space>[Subject 2 name]<space>... etc.

	unsigned int subjectCount = myClient.GetSubjectCount().SubjectCount;
	System::String ^ strAll = subjectCount.ToString();

	for(unsigned int subjectIndex = 0; subjectIndex < subjectCount; ++subjectIndex) {
		std::string stdStringSubjectName = myClient.GetSubjectName(subjectIndex).SubjectName;
		System::String ^ subjectName = gcnew System::String(stdStringSubjectName.c_str());
		strAll = strAll + " " + subjectName + " " + getTranslation(stdStringSubjectName) + " " + getRotation(stdStringSubjectName);
	}

	return strAll;

}